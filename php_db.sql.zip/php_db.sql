-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 05:26 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `name` text NOT NULL,
  `roll` text NOT NULL,
  `class` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`name`, `roll`, `class`, `contact`, `email`) VALUES
('vaibhavi patil', '19434', 'IF6', '987654321', 'vaibhavip407@gmail.com'),
('vaibhavi patil', '19434', 'IF6', '987654321', 'vaibhavip407@gmail.com'),
('vaibhavi patil', '19434', 'IF6', '987654321', 'vaibhavip407@gmail.com'),
('vaibhavi patil', '19434', 'IF6', '987654321', 'vaibhavip407@gmail.com'),
('vaibhavi patil', '19434', 'IF1', '987654321', 'vaibhavip407@gmail.com'),
('pranjli', '1456', 'IF4', '1353876734', 'pranjli134@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `fedfaculty`
--

CREATE TABLE `fedfaculty` (
  `que1` text NOT NULL,
  `que2` text NOT NULL,
  `que3` text NOT NULL,
  `que4` text NOT NULL,
  `que5` text NOT NULL,
  `que6` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fedfaculty`
--

INSERT INTO `fedfaculty` (`que1`, `que2`, `que3`, `que4`, `que5`, `que6`) VALUES
('excellent', 'excellent', 'excellent', 'excellent', 'excellent', 'Excellent!'),
('excellent', 'excellent', 'excellent', 'excellent', 'excellent', 'ALL GOOD!'),
('excellent', 'excellent', 'excellent', 'excellent', 'excellent', 'Excellent!'),
('excellent', 'excellent', 'excellent', 'excellent', 'excellent', 'Excellent!'),
('excellent', 'excellent', 'excellent', 'excellent', 'excellent', 'Very good!'),
('excellent', 'excellent', 'verygood', 'excellent', 'verygood', 'very good');

-- --------------------------------------------------------

--
-- Table structure for table `iffaculty`
--

CREATE TABLE `iffaculty` (
  `ID` int(11) NOT NULL,
  `class` text NOT NULL,
  `subject` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `iffaculty`
--

INSERT INTO `iffaculty` (`ID`, `class`, `subject`) VALUES
(1, 'IF SEM 6', 'Management'),
(2, 'IF SEM 6', 'Wireless Mobile Network'),
(3, 'IF SEM 6', 'Wireless Mobile Network'),
(4, 'IF SEM 6', 'Web based Application using php'),
(5, 'IF SEM 6', 'Mobile Applicaton Development'),
(6, 'IF SEM 6', 'Web based Application using php'),
(7, 'IF SEM 1', 'Basic Mathematics'),
(8, 'IF SEM 4', 'JAVA PROGRAMMING');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem1faculty`
--

CREATE TABLE `ifsem1faculty` (
  `ID` int(11) NOT NULL,
  `English` text NOT NULL,
  `Basic_science` text NOT NULL,
  `Basic_maths` text NOT NULL,
  `Graphics` text NOT NULL,
  `Workshop_practices` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem1faculty`
--

INSERT INTO `ifsem1faculty` (`ID`, `English`, `Basic_science`, `Basic_maths`, `Graphics`, `Workshop_practices`) VALUES
(1, 'Mrs.Biradar', 'Ms.Patil', 'Ms.Mankar', 'Mrs.Patil', 'Mr.Kapil Chavan');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem2faculty`
--

CREATE TABLE `ifsem2faculty` (
  `ID` int(11) NOT NULL,
  `EEC` text NOT NULL,
  `AMT` text NOT NULL,
  `BEC` text NOT NULL,
  `PCI` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem2faculty`
--

INSERT INTO `ifsem2faculty` (`ID`, `EEC`, `AMT`, `BEC`, `PCI`) VALUES
(1, 'Ms.Rohit gavali', 'Mr.Jamdade', 'Mrs.Pranita', 'Mrs.Varne Rohini');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem3faculty`
--

CREATE TABLE `ifsem3faculty` (
  `ID` int(11) NOT NULL,
  `OOP` text NOT NULL,
  `DSU` text NOT NULL,
  `POD` text NOT NULL,
  `DCO` text NOT NULL,
  `DTM` text NOT NULL,
  `AMT` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem3faculty`
--

INSERT INTO `ifsem3faculty` (`ID`, `OOP`, `DSU`, `POD`, `DCO`, `DTM`, `AMT`) VALUES
(1, 'Mrs.Kshirsagar', 'Mrs.Rohini varne', 'Mr.Bodhe', 'Mr.Patil', 'Mrs.Ambika', 'Mr.Chavan');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem4faculty`
--

CREATE TABLE `ifsem4faculty` (
  `ID` int(11) NOT NULL,
  `AJP` text NOT NULL,
  `SEN` text NOT NULL,
  `DBMS` text NOT NULL,
  `CNE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem4faculty`
--

INSERT INTO `ifsem4faculty` (`ID`, `AJP`, `SEN`, `DBMS`, `CNE`) VALUES
(1, 'Mrs.Rohini Varne', 'Mrs.Ambika ', 'Mr.Bodhe', 'Mr.Patil');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem5faculty`
--

CREATE TABLE `ifsem5faculty` (
  `ID` int(11) NOT NULL,
  `ENS` text NOT NULL,
  `OSY` text NOT NULL,
  `AJP` text NOT NULL,
  `CSS` text NOT NULL,
  `ITR` text NOT NULL,
  `CPP` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem5faculty`
--

INSERT INTO `ifsem5faculty` (`ID`, `ENS`, `OSY`, `AJP`, `CSS`, `ITR`, `CPP`) VALUES
(1, 'Mr.Salve', 'Mr.Bhosale', 'Mrs.Rohini ', 'Mrs.Khandekar', 'Mrs.Kshirsagar', 'Mrs.Kshirsagar');

-- --------------------------------------------------------

--
-- Table structure for table `ifsem6faculty`
--

CREATE TABLE `ifsem6faculty` (
  `ID` int(11) NOT NULL,
  `MGT` text NOT NULL,
  `WMN` text NOT NULL,
  `WBP` text NOT NULL,
  `MAD` text NOT NULL,
  `ETI` text NOT NULL,
  `CPE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ifsem6faculty`
--

INSERT INTO `ifsem6faculty` (`ID`, `MGT`, `WMN`, `WBP`, `MAD`, `ETI`, `CPE`) VALUES
(1, 'Ms.Snehal Patil', 'Mrs.Patil', 'Mrs.Bhosale', 'Mrs.Yewale', 'Mrs.Rohini Varne', 'Mrs.Kshirsagar');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `user` text NOT NULL,
  `pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`user`, `pass`) VALUES
('Sanchi Jamkar', 'sanchu123'),
('vaibhavi', 'vaibhavi123'),
('Mayuri Gaikwad', 'mayuri123'),
('Sandhya Hote', 'sandhya123'),
('ashiwini', 'ashiwini124'),
('Pranjal', 'pranjal123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `iffaculty`
--
ALTER TABLE `iffaculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem1faculty`
--
ALTER TABLE `ifsem1faculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem2faculty`
--
ALTER TABLE `ifsem2faculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem3faculty`
--
ALTER TABLE `ifsem3faculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem4faculty`
--
ALTER TABLE `ifsem4faculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem5faculty`
--
ALTER TABLE `ifsem5faculty`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ifsem6faculty`
--
ALTER TABLE `ifsem6faculty`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `iffaculty`
--
ALTER TABLE `iffaculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ifsem1faculty`
--
ALTER TABLE `ifsem1faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ifsem2faculty`
--
ALTER TABLE `ifsem2faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ifsem3faculty`
--
ALTER TABLE `ifsem3faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ifsem4faculty`
--
ALTER TABLE `ifsem4faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ifsem5faculty`
--
ALTER TABLE `ifsem5faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ifsem6faculty`
--
ALTER TABLE `ifsem6faculty`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
