<?php
   $db = mysqli_connect("localhost","root","","php_db");
   if(isset($_POST['Update']))
   {
    $name=$_POST['name1'];    
    $query="UPDATE ifsem5faculty SET ENS='$name' where id=1";
        
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }   
}

  

   if(isset($_POST['Update1']))
   {
    $name=$_POST['name2'];   
    $query="UPDATE ifsem5faculty SET OSY='$name' where id=1";
        
   
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }     
   }
   if(isset($_POST['Update2']))
   {
    $name=$_POST['name3'];   
    $query="UPDATE ifsem5faculty SET AJP='$name' where id=1";
        
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }  
   }
   if(isset($_POST['Update3']))
   {
    $name=$_POST['name4'];   
    $query="UPDATE ifsem5faculty SET CSS='$name' where id=1";
        
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }     
   }
   if(isset($_POST['Update4']))
   {
    $name=$_POST['name5'];   
    $query="UPDATE ifsem5faculty SET ITR='$name' where id=1";
        
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }       
   }
   if(isset($_POST['Update5']))
   {
    $name=$_POST['name6'];   
    $query="UPDATE ifsem5faculty SET CPP='$name' where id=1";
        
    $result=mysqli_query($db, $query);
    if($result)
    {
      echo "Faculty record updated successfully";
      exit();
    }       
   }
   


   ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    
    <style>
        body{
            background-color:lightblue;
        }
        #table1{
            background-color:    rgba(242, 244, 248, 0.932);
            position: relative;
            left:350px;
            top:-400px;
        }
        #container2{
            position: relative;
            top: -305px;
            left: 300px;
            border: none;

        }
        .container
        {
            background-color:    rgba(242, 244, 248, 0.932);
           position: relative;
           left:-50px;
            height: 450px;
            width: 600px;
        }
        div {
            border: 1px solid;
            margin: 0px 100px 0px 50px;
            width: 450px;
            height: 350px;

        }

        h1 {
            font-size: 30px;
        }

        h2 {
            position: relative;
            right: 100px;
            font-size: 20px;
            margin: 0px 150px 0px 230px;
            width: 200px;

        }

        p {
            position: relative;
            margin:10px 100px 0px 100px;
            font-size: 20px;
        }
      
        .Update1
        {
            position: relative;
            width: 50px;
            height: 150px;
            text-decoration: none;
            margin-left:500px;
            margin-top: -150px;
            border: none;

        }

        .Update
        {
            position: relative;
            width: 50px;
            height: 150px;
            text-decoration: none;
            margin-left:300px;
            margin-top: -290px;
            border: none;

        }
    #maindiv
        {
            
            border: none;

        }
        #Confirm
{
    position: relative;
         
            right: 100px;
    
    background-color:lightskyblue;

    width: 20%;
    
}
   
       input
      {
          position: relative;
          margin-left: 0px 400px 0px 400px;
      }
      #btn1
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
      #btn2
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
      #btn3
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
      #btn4
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
      #btn5
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
      #btn6
      {
        position: relative;
         
         left: 1px;
 
 background-color:green;
 color: white;
      }
    </style>


</head>

<body>
    <center><h1>SUBJECT FACULTY</h1></center>
    <div class="container">
    <center>
        
    </center>
    <div id="maindiv">
        <p>
       <center><h2>&nbspSEMESTER 5</h2></center>
        <br>

        &nbspENS<br><br><br><br>
     
        &nbspOSY<br><br><br>
        &nbsp AJP <br><br><br>
        
        &nbspCSS<br><br><br>

        &nbspITR<br><br><br>
        &nbspCPP<br><br><br>
       

        </p> 
    </div>
    <div id="container2">
        <form action="" method="post">
            
        <input type="text" name="name1"value="">
            <input type="submit" name="Update"value="Update"id="btn1" ><br><br><br>
            
        </form>
        <form action="" method="post">
            <input type="text" name="name2"value="" >
            <input type="submit" name="Update1"value="Update"id="btn2" ><br><br><br>
        </form>
        <form action="" method="post">
            <input type="text" name="name3"value="" >
            <input type="submit" name="Update2"value="Update" id="btn3"><br><br><br>
        </form>
        <form action="" method="post">
            <input type="text" name="name4"value="" >
            <input type="submit" name="Update3"value="Update"id="btn4" ><br><br><br>
        </form>
        <form action=""method="post">
            <input type="text" name="name5"value="" >
            <input type="submit" name="Update4"value="Update"id="btn5" ><br><br><br>
        </form>
        <form action=""method="post">
            <input type="text" name="name6"value="" >
            <input type="submit" name="Update5"value="Update"id="btn6" ><br><br><br>
        </form>
       
        <form action=""method="post">
        <input type="submit"name="view" value="View Faculty"id="Confirm">
    </form>
    </div>

</div>
<table align="center" border="1px" style="width:300px; line-height:30px;" id="table1">
      <tr> 
       <th colspan="6"><h2>Faculty Record</h2></th> 
      </tr>
      <t>

       <th> ENS </th> 
        <th> OSY </th> 
         <th> AJP </th> 
         <th> CSS </th> 
         <th> ITR </th> 
         <th> CPP </th> 
         </t>
         <?php

if(isset($_POST['view']))
   {
    $db = mysqli_connect("localhost","root","","php_db");
    
    
     $query1=mysqli_query($db,'select * from ifsem5faculty where id=1');
   while($row=mysqli_fetch_assoc($query1))
   {
    ?>
     <tr>
         <td><?php echo $row['ENS'];?></td>
         <td><?php echo $row['OSY']; ?></td>
         <td><?php echo $row['AJP']; ?></td>
         <td><?php echo $row['CSS'] ;?></td>
         <td><?php echo $row['ITR'] ;?></td>
         <td><?php echo $row['CPP'] ;?></td>
     </tr>
     <?php
    }
        
   
}
?>
         </table>

 

</body>

</html>