<?php

ob_end_clean();
require('fpdf/fpdf.php');
$pdf = new FPDF();

$pdf->AddPage();
$pdf->SetFont("Arial","i",8);
$pdf->Cell(200,20,"Faculty Feedback Management System","0","1","C");
$pdf->setLeftMargin(35);
$pdf->setTextColor(0,0,0);       

$con=new PDO("mysql:host=localhost;dbname=php_db","root","");

 $query="SELECT*FROM iffaculty";
 
    $result = $con->prepare($query);
    $result->execute();

    $con1=new PDO("mysql:host=localhost;dbname=php_db","root","");

 $query1="SELECT*FROM fedfaculty";
 
    $result1 = $con1->prepare($query1);
    $result1->execute();
    if($result->rowCount()!=0  )
    {
        $pdf->Cell(20,10,"ID","1","0","D");
        $pdf->Cell(55,10,"Class","1","0","D");
        $pdf->Cell(55,10,"Subject","1","1","D");
       
            while($sem1 = $result->fetch())
        {
            $pdf->Cell(20,10,$sem1['ID'],"1","0","C");
            $pdf->Cell(55,10,$sem1['class'],"1","0","C");
            $pdf->Cell(55,10,$sem1['subject'],"1","1","C");
        }
    }
   
    if( $result1->rowCount()!=0 )
    {
        $pdf->Cell(20,10,"Question 1","1","0","C");  
        $pdf->Cell(20,10,"Question 2","1","0","C");
        $pdf->Cell(20,10,"Question 3","1","0","C");
        $pdf->Cell(20,10,"Question 4","1","0","C");
        $pdf->Cell(20,10,"Question 5","1","0","C");
        $pdf->Cell(30,10,"Question 6","1","1","C");
        while( $sem2 = $result1->fetch())
        {
                  
            $pdf->Cell(20,10,$sem2['que1'],"1","0","C");
            $pdf->Cell(20,10,$sem2['que2'],"1","0","C");
            $pdf->Cell(20,10,$sem2['que3'],"1","0","C");
            $pdf->Cell(20,10,$sem2['que4'],"1","0","C");
            $pdf->Cell(20,10,$sem2['que5'],"1","0","C");
            $pdf->Cell(30,10,$sem2['que6'],"1","1","C");
        }
        
    }          
  
    else{
        echo "Not found record";
    }


$pdf->Output();
?>