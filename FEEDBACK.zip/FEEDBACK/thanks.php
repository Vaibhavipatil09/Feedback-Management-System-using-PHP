<!DOCTYPE html>
<html>
    <head>
	     <title>Feedback </title>
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
         <style>
        
      
        body {
            width: 100%;
            height: 100vh;
          
            display: flex;
            justify-content: center;
            align-items: center;

           font-size: 20px;
        }
        img
        {
            position: absolute;
            top:0px;
            display: block;
            left:0px;
            right: 0px;
            width: 100%;
            height:700px;

           background-image:cover;
        
        }

    

        .container {
            position: absolute;
               top:30px;
            width: 90%;
            height: 550px;
            
            border: 1px solid;
            background-color: white;
            display: flex;
            flex-direction: column;
            padding: 40px;
            justify-content: center;
            background-color:rgba(242, 244, 248, 0.932)
        } 
   
h1
{
font-size: 100px;
}



</style>
    <head>
    <body>
  
        <img src="thank.jpeg">
      
        <div class="container">
         <center>
        <h1>Thank You For Your Feedback!</h1>
    </center> 
      

      
    </div> 
    </body>
</html>
