<?php
   
   if(isset($_POST['submit']))
   {
   
        $class=$_POST['class'];
        
      

        if($class=="IF1")
        {
          
          header("Location:adminsem1.php");
          exit();
        }
        if($class=="IF2")
        {
         
          header("Location:adminsem2.php");
          exit();
        }
        if($class=="IF3")
        {
          
          header("Location:adminsem3.php");
          exit();
        }
        if($class=="IF4")
        {
         
          header("Location:adminsem4.php");
          exit();
        }
        if($class=="IF5")
        {
         
          header("Location:adminsem5.php");
          exit();
        }
        if($class=="IF6")
        {
          
          header("Location:adminsem6.php");
          exit();
        }
        
    }
     
    if(isset($_POST['submit1']))
   {
      
       
            header("Location:foreg1.php");
            exit();
      
       }
   
?>
</html>
<!DOCTYPE html>
<html>

<head>
    <title>Customer Details</title>

    <head>
        <style>
          body{
            background-color:lightblue;
          }
            #btn1
            {
                position: relative;
                left:190px;
                top:140px;
                height:40px;
                width:90px;
                font-size:20px;
                background-color:lightblue;
            }
            #btn2
            {
                position: relative;
                left:400px;
                top:400px;
                height:40px;
                width:200px;
                font-size:20px;
                background-color:blue;
                color:white;
            }
            div {
             
                border: 1px solid;
                width: 500px;
                height: 350px;
                margin: 10px 200px 10px 400px;
                background-color:    rgba(242, 244, 248, 0.932);
            }
            h1
            {
                 font-size:40px;
            }  
              select
            {
                position: relative;
                margin-right:300px;

            }
            label
            {
                font-size:20px;
                position: relative;
                margin-right: 10px;
                top: 100px;
                left:100px;
            }
          
      #set{
        position: relative;
        top:100px;
        left:100px;
      }
        
        </style>


    <body>
     <form action=""method="post">

        <center>
        <h1>FACULTY UPDATION!</h1>
        </center>

            <div>

              <br>

        <label>Select Class-</label>
       
       
       <input type="text" value="" name="class" placeholder="eg-IF1" id="set">
        <br> <br>
        <input type="submit" value="next" name="submit" id="btn1">
        <input type="submit" value="View Feedback PDF" name="submit1" id="btn2">


       
    </div>

    </form>
       

    </body>

</html>