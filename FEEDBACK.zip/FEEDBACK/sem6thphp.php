<?php $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 6";
          if($_POST['radio']=="WMN")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`)  VALUES ('$class', 'Wireless Mobile Network', 'Mrs.Mayuri Patil')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:facultysem1.php");
            } 
              exit();
          }
          if($_POST['radio']=="MGT")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`)  VALUES ('$class', 'Management', 'Mrs.Snehal Patil')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:facultysem1.php");
             } 
               exit();
           }
          if($_POST['radio']=="WBP")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`) VALUES ('$class', 'Web based Application using php', 'Mr.Bhosale')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:facultysem1.php");
             } 
               exit();
           }
           if($_POST['radio']=="MAD")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`)  VALUES ('$class', 'Mobile Applicaton Development', 'Mrs.Pranali Yewale')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:facultysem1.php");
              } 
                exit();
            }
            if($_POST['radio']=="E1")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`)  VALUES ('$class', 'Emerging trends in CO and IF', 'Mrs.Rohini varne')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:facultysem1.php");
               } 
                 exit();
             }
             if($_POST['radio']=="CPP")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`,`faculty`)  VALUES ('$class', 'Capstone Project Planning and Report writing', 'Mrs.Anita Kshirsagar')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:facultysem1.php");
                } 
                  exit();
              }
             
        } 
        
      }

?>