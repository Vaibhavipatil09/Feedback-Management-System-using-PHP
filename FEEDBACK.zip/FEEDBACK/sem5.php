
    <?php
    $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 5";
          if($_POST['radio']=="EDE")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Environmental Studies')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem5sub1.php");
            } 
              exit();
          }
          if($_POST['radio']=="CSS")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Client Side Scripting Language')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem5sub4.php");
             } 
               exit();
           }
          if($_POST['radio']=="AJP")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', 'Advanced Java Programming')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem5sub3.php");
             } 
               exit();
           }
           if($_POST['radio']=="OS")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Operating System')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem5sub2.php");
              } 
                exit();
            }
            if($_POST['radio']=="IT")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Industrial Training')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem5sub5.php");
               } 
                 exit();
             }
             if($_POST['radio']=="CPP")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Capstone Project Planning')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:sem5sub6.php");
                } 
                  exit();
              }
             
        } 
        
      }

?>
    
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK4.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 5th SEMISTER</h3>
<form  action="" method="post" id="form3">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="EDE" checked value="EDE">
  <label class="form-check-label" for="EDE">
Environmental Studies

  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="OS" checked value="OS">
  <label class="form-check-label" for="OS">
   
	Operating System
    
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="AJP" checked value="AJP">
  <label class="form-check-label" for="AJP">
    
    	Advanced Java Programming
  </label>
</div>
<br>

<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="CSS" checked value="CSS">
  <label class="form-check-label" for="CSS">
    
    Client Side Scripting Language
  </label>
</div>
<br>

<div class="form-check">
    <input class="form-check-input" type="radio" name="radio" id="IT" checked value="IT">
    <label class="form-check-label" for="IT">
  
	Industrial Training
    </label>
  </div>
  <br>

<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="CPP" checked value="CPP">
  <label class="form-check-label" for="CPP">

	Capstone Project Planning
  </label>
</div>
<br>


            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
              </div>
            </div>

      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>