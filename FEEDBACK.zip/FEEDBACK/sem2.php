
    <?php
    $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 2";
          if($_POST['radio']=="EEC")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'ELEMENTS OF ELECTRICAL ENGINEERING')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem2sub1.php");
            } 
              exit();
          }
          if($_POST['radio']=="AM")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', 'APPLIED MATHEMATICS')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem2sub2.php");
             } 
               exit();
           }
           if($_POST['radio']=="BEC")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'BASIC ELECTRONICS')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem2sub3.php");
              } 
                exit();
            }
            if($_POST['radio']=="C")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'PROGRAMMING IN C ')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem2sub4.php");
               } 
                 exit();
             }
            
             
        } 
        
      }

?>
    
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK2.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 2nd SEMISTER</h3>
	<form  action="" method="post" id="form2">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="EEC" checked value="EEC">
  <label class="form-check-label" for="EEC">
    ELEMENTS OF ELECTRICAL ENGINEERING

  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="AM" checked value="AM">
  <label class="form-check-label" for="AM">
   
    APPLIED MATHEMATICS

    
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="BEC" checked value="BEC">
  <label class="form-check-label" for="BEC">
    
    BASIC ELECTRONICS
  
   
    
  </label>
</div>
<br>


<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="C" checked value="C">
  <label class="form-check-label" for="C">

    PROGRAMMING IN ‘C’
    
  </label>
</div>
<br>

            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
                    </div>
            </div>
      </form>
      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>