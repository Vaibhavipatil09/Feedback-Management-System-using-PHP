<?php
    $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 3";
          if($_POST['radio']=="CPP")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Object Oriented Programming Using C++')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem3sub1.php");
            } 
              exit();
          }
          if($_POST['radio']=="DS")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', 'Data Structure Using C')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem3sub2.php");
             } 
               exit();
           }
           if($_POST['radio']=="DB")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Principles of Database')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem3sub3.php");
              } 
                exit();
            }
            if($_POST['radio']=="DC")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Data Communication')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem3sub4.php");
               } 
                 exit();
             }
             if($_POST['radio']=="DTM")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Digital Techniques and Microprocessor')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:sem3sub5.php");
                } 
                  exit();
              }
              if($_POST['radio']=="AMT")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Applied Multimedia Techniques')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:sem3sub6.php");
                } 
                  exit();
              }
             
        } 
        
      }

?>
    
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK5.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 3rd SEMISTER</h3>
<form  action="" method="post" id="form3">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="CPP" checked value="CPP">
  <label class="form-check-label" for="CPP">
   Object Oriented Programming Using C++
  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="DS" checked value="DS">
  <label class="form-check-label" for="DS">
    Data Structure Using C
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="DB" checked value="DB">
  <label class="form-check-label" for="DB">
    
    	Principles of Database
  </label>
</div>
<br>
<div class="form-check">
    <input class="form-check-input" type="radio" name="radio" id="DC" checked value="DC">
    <label class="form-check-label" for="DC">
        Data Communication
    </label>
  </div>
  <br>

<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="DTM" checked value="DTM">
  <label class="form-check-label" for="DTM">

	Digital Techniques and Microprocessor	
  </label>
</div>
<br>

<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="AMT" checked value="AMT">
  <label class="form-check-label" for="AMT">

		Applied Multimedia Techniques
  </label>
</div>
<br>


            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
              </div>
            </div>

      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>