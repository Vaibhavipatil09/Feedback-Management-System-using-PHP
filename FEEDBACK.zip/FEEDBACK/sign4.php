<?php
   $db = mysqli_connect("localhost","root","","php_db");
   if(isset($_POST['submit']))
   {
        $user=$_POST['user'];
        $pass=$_POST['pass'];

        $query="SELECT * FROM `student` WHERE user='$user' AND pass='$pass'";

        $result = mysqli_query($db, $query);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  

    
        if($count == 1){  
           echo "<h1>ACCOUNT ALREADY EXITS</h1>"; 
            exit();
        }  
        else{  
            $query1="INSERT INTO `student` (`user`,`pass`) VALUES ('$user', '$pass')";
        
            $result1=mysqli_query($db, $query1);
            if($result1)
            {
            echo "<script>alert('REGISTER SUCCESSFULLY!');</script>";
            }
            else
            {
            echo "<script>alert('something went wrong');</script>";
            }
        }    
       }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>Sign up</title>
  <style>
    @import url(https://fonts.googleapis.com/css?family=Roboto:400,300,500);
*:focus {
  outline: none;
}

body {
  margin: 0;
  padding: 0;
  background: #DDD;
  font-size: 16px;
  color: #222;
  font-family: 'Roboto', sans-serif;
  font-weight: 300;
}



#login-box1{
  position: relative;
  margin: 7% auto;
  margin-left: 40%;
  width: 300px;
  height: 350px;
  background: #FFF;
  border-radius: 2px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
}


.left {
  position: absolute;
  top: 0;
  left: 0;
  box-sizing: border-box;
  padding: 40px;
  width: 300px;
  height: 400px;
}

h2 {
  margin: 0 0 20px 0;
  font-weight: 300;
  font-size: 28px;
}

input[type="text"],
input[type="password"] {
  display: block;
  box-sizing: border-box;
  margin-bottom: 20px;
  padding: 4px;
  width: 220px;
  height: 32px;
  border: none;
  border-bottom: 1px solid #AAA;
  font-family: 'Roboto', sans-serif;
  font-weight: 400;
  font-size: 15px;
  transition: 0.2s ease;
}

input[type="text"]:focus,
input[type="password"]:focus {
  border-bottom: 2px solid #16a085;
  color: #16a085;
  transition: 0.2s ease;
}

input[type="submit"] {
  margin-top: 28px;
  width: 120px;
  height: 32px;
  background: #16a085;
  border: none;
  border-radius: 2px;
  color: #FFF;
  font-family: 'Roboto', sans-serif;
  font-weight: 500;
  text-transform: uppercase;
  transition: 0.1s ease;
  cursor: pointer;
}

input[type="submit"]:hover,
input[type="submit"]:focus {
  opacity: 0.8;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}

input[type="submit"]:active {
  opacity: 1;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  transition: 0.1s ease;
}



#start2{
    height:30px;
    width:130px;
    position: relative;
    top:320px;
    left:220px;

    font-size: 15px;
    
    
   
}



body{
    background-image:url("clg2.webp");
    background-repeat:no-repeat;
    background-size: 1400px;
    background-position:center;
    background-attachment: fixed;
}

  </style>
</head>
<body>
  <br>
  
  
    
  
 
  
    <div id="login-box1">
        <div class="left">
          <h2>STUDENT REGISTRATION</h2>
          <form method='post'>
          
          <input type="text" name="user" placeholder="username" id="user"/>
         
          <input type="password" name="pass" placeholder="Password" id="pass" /> 
        
          &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp  
          <input type="submit" name="submit" value="REGISTER" />
        </div>
        
      
        </form>
      </div>
</body>
</html>