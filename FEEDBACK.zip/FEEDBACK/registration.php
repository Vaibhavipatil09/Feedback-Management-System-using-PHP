<?php
   $db = mysqli_connect("localhost","root","","grwpt_hostel");
   if(isset($_POST['submit']))
   {
   
        $id=$_POST['id'];
        $stud_name=$_POST['stud_name'];
        $stud_phone=$_POST['stud_phone'];
        $hostel_name=$_POST['hostel_name'];
        $room_no=$_POST['room_no'];
        $stud_address=$_POST['stud_address'];
        $parents_name=$_POST['parents_name'];
        $parents_phone=$_POST['parents_phone'];
        $guardian_name=$_POST['guardian_name'];
        $guardian_phone=$_POST['guardian_phone'];
        $guardian_address=$_POST['guardian_address'];

        $query="INSERT INTO `registration` (`sr_no`,`id`, `stud_name`, `stud_phone`, `hostel_name`, `room_no`,`stud_address`,`parents_name`, `parents_phone`, `guardian_name`, `guardian_phone`,`guardian_address`) VALUES (NULL, '$id', '$stud_name', '$stud_phone', '$hostel_name', '$room_no','$stud_address','$parents_name', '$parents_phone', '$guardian_name', '$guardian_phone','$guardian_address')";
        
        $result=mysqli_query($db, $query);
        if($result)
        {
        echo "<script>alert('Data saved successfully');</script>";
        }
        else
        {
        echo "<script>alert('something went wrong');</script>";
        }
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <link rel="stylesheet" href="Reason.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Registration | GRWPT</title>
</head>
<body text-align="center">
<!-- Form Name -->
        <legend>
          <center>
            <h2><b>Government Residence Women Polytechnic, Tasgaon</b></h2>
          </center>
        </legend><br>
        <center>
		<!-- Text input-->
          <div id="div1">
            <div class="form-group">
				<h2>Hostel Registration Form</h2> <br><br>
				<!--Student info-->
				<form method='post'>
				<label><h3>Student Details:</h3></label> <br><br>
				<label for="start">Id:</label>
				<input type="text" id="id" name="id"><br><br><br>
				<label for="start">Student Name:</label>
				<input type="text" name="stud_name" id="stud_name"><br><br><br>
				<label for="start">Student Phone:</label>
				<input type="text" name="stud_phone" id="stud_phone"><br><br><br>
				<label for="start">Hostel Name:</label>
				<input type="text" name="hostel_name" id="hostel_name"><br><br><br>
				<label for="start">Room No:</label>
				<input type="text" name="room_no" id="room_no"><br><br><br>
				<label for="start">Student Address:</label>
				<textarea class="input" name="stud_address" cols="40"rows="5"id="stud_address" placeholder="Enter home town,pin code,Tal, Dist"></textarea><br><br><br>
		
		</div>
			</div>	
			 <div id="div1">
            <div class="form-group">
			<!--Parents info-->
				<label><h3>Parent's Details:</h3></label> <br><br>
				<label for="start">Parent's Name:</label>
				<input type="text" name="parents_name" id=" parents_name"><br><br><br>
				<label for="start">parents Phone No:</label>
				<input type="text" name="parents_phone" id="parents_phone"><br><br><br>
		</div>
			</div>
			 <div id="div1">
            <div class="form-group">
			<!--Local Guardian's  info-->
			<label><h3>Local Guardian Details:</h3></label> <br><br>

				<label for="start">Guardian Name:</label>
				<input type="text" name="guardian_name" id="guardian_name"><br><br><br>
				<label for="start">Guardian Phone No:</label>
				<input type="text" name="guardian_phone" id="guardian_phone"><br><br><br>
				<label for="start">Guardian Address:</label>
				<textarea name="guardian_address" id="guardian_address"cols="40"rows="5" placeholder="Enter home town,pin code,Tal, Dist"></textarea><br><br><br>

				<button type="submit" id="submit" name="submit">Register</button>
				</form>
				</div>
			</div>
			</center>
</body>
</html>