<?php
    $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
          $class="IF SEM 1";
          if($_POST['radio']=="English")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'English')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem1sub1.php");
            } 
              exit();
          }
          if($_POST['radio']=="Science")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', 'Basic Science Physics Chemistry')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem1sub2.php");
             } 
               exit();
           }
           if($_POST['radio']=="basicm")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Basic Mathematics')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem1sub3.php");
              } 
                exit();
            }
            if($_POST['radio']=="Graphics")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Engineering Graphics')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem1sub4.php");
               } 
                 exit();
             }
             if($_POST['radio']=="Basic Workshop Practice")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Basic Workshop Practice')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:sem1sub5.php");
                } 
                  exit();
              }
             
        } 
        
      }

?>
     
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK1.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 1St SEMISTER</h3>
<	<form  action="" method="post" id="form1">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="eng" checked value="English">
  <label class="form-check-label" for="eng">
    English
    
  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="sci" checked value="Science">
  <label class="form-check-label" for="sci">
   
    Basic Science Physics
    Chemistry
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="maths" checked value="basicm">
  <label class="form-check-label" for="maths">
     Basic Mathematics
   
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="graphics" checked value="Graphics">
  <label class="form-check-label" for="graphics">
     Engineering Graphics
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="wbp" checked value="Basic Workshop Practice">
  <label class="form-check-label" for="wbp">

 Basic Workshop Practice
    
    
  </label>
</div>


            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
              </div>
            </div>
      </form>
      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>