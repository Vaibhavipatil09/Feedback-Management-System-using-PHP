
    <?php
    $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 4";
          if($_POST['radio']=="java")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'JAVA PROGRAMMING')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem4sub1.php");
            } 
              exit();
          }
          if($_POST['radio']=="SNE")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', '  SOFTWARE ENGINEERING')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem4sub2.php");
             } 
               exit();
           }
           if($_POST['radio']=="DM")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'DATABASE MANAGEMENT')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem4sub3.php");
              } 
                exit();
            }
            if($_POST['radio']=="CNE")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', ' COMPUTER NETWORK')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem4sub4.php");
               } 
                 exit();
             }
             
        } 
        
      }

?>
    
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK3.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 4th SEMISTER</h3>
<form  action="" method="post" id="form3">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="java" checked value="java">
  <label class="form-check-label" for="java">
    JAVA PROGRAMMING

  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="SNE" checked value="SNE">
  <label class="form-check-label" for="SNE">
   
    SOFTWARE ENGINEERING

    
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="DM" checked value="DM">
  <label class="form-check-label" for="DM">
    
    
    DATABASE MANAGEMENT
    
  </label>
</div>
<br>


<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="CNE" checked value="CNE">
  <label class="form-check-label" for="CNE">

    COMPUTER NETWORK
  </label>
</div>
<br>

            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
              </div>
            </div>

      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>