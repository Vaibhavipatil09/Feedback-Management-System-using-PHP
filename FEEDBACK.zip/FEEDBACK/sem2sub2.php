<?php
$db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        
            $one=$_POST['view'];
            $two=$_POST['view2'];
            $three=$_POST['view3'];
            $four=$_POST['view4'];
            $five=$_POST['view5'];
            $six=$_POST['view6'];
            $query="INSERT INTO `fedfaculty` (`que1`,`que2`,`que3`,`que4`,`que5`,`que6`)  VALUES ('$one','$two','$three','$four','$five','$six')";
            $result=mysqli_query($db, $query);
            if($result)
            {
                echo "<script>alert('Thanks for your feedback!');</script>";
                header("Location:thanks.php");
                exit();
            } 
        } 
      
  ?>  
<!DOCTYPE html>
<html>

<head>
	<title>FeedbacK Engine</title>
	<!-- custom-theme -->

	
	</script>
	<!-- //custom-theme -->
	<link rel="stylesheet" href="style.css">
	<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<style>
    #vai{
        position: relative;
        top: -1700px;
        left: 380px;
    }
</style>
</head>

<body class="agileits_w3layouts">
	<h1 class="agile_head text-center">FEEDBACK FOR FACULTY </h1>
	<div class="w3layouts_main wrap">

		<form action="" method="post" class="agile_form">
			<h2>1.How much would you like to rate our faculty for Punctuality and Discipline</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view" value="excellent" id="excellent1" required>
					<label for="excellent1">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view" value="verygood" id="good2">
					<label for="good2"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view" value="good" id="good3">
					<label for="good3">good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view" value="poor" id="poor4">
					<label for="poor4">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view" value="bad" id="neutral4">
					<label for="neutral4">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>2.How much would you like to rate our faculty for Domain Knowledge</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view2" value="excellent" id="excellentt" required>
					<label for="excellentt">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view2" value="verygood" id="goodt">
					<label for="goodt"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view2" value="good" id="good2t">
					<label for="good2t"> good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view2" value="poor" id="poor2t">
					<label for="poor2t">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view2" value="bad" id="bad2t">
					<label for="bad2t">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>3.How much would you like to rate our faculty for Presentation Skill and interaction with student </h2>
				<ul class="agile_info_select">
					<li><input type="radio" name="view3" value="excellent" id="excellenttt" required>
						<label for="excellenttt">excellent</label>
						<div class="check w3"></div>
					</li>
					<li><input type="radio" name="view3" value="verygood" id="goodtt">
						<label for="goodtt"> very good</label>
						<div class="check w3ls"></div>
					</li>
					<li><input type="radio" name="view3" value="good" id="good2tt">
						<label for="good2tt"> good</label>
						<div class="check w3ls"></div>
					</li>
					
					<li><input type="radio" name="view3" value="poor" id="poor2tt">
						<label for="poor2tt">poor</label>
						<div class="check w3_agileits"></div>
					</li>
					<li><input type="radio" name="view3" value="bad" id="bad2tt">
						<label for="bad2tt">bad</label>
						<div class="check wthree"></div>
					</li>
				</ul>
			<h2>4.How much would you like to rate our faculty for solve difficulties.</h2>
				<ul class="agile_info_select">
					<li><input type="radio" name="view4" value="excellent" id="excellentttt" required>
						<label for="excellentttt">excellent</label>
						<div class="check w3"></div>
					</li>
					<li><input type="radio" name="view4" value="verygood" id="goodttt">
						<label for="goodttt"> very good</label>
						<div class="check w3ls"></div>
					</li>
					<li><input type="radio" name="view4" value="good" id="good2ttt">
						<label for="good2ttt"> good</label>
						<div class="check w3ls"></div>
					</li>
					
					<li><input type="radio" name="view4" value="poor" id="poor2ttt">
						<label for="poor2ttt">poor</label>
						<div class="check w3_agileits"></div>
					</li>
					<li><input type="radio" name="view4" value="bad" id="bad2ttt">
						<label for="bad2ttt">bad</label>
						<div class="check wthree"></div>
					</li>
				</ul>
			<h2>5.How much would you ke to rate ourfaculty for Effective use of Teaching Aids</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view5" value="excellent" id="excellenttttt" required>
					<label for="excellenttttt">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view5" value="verygood" id="goodtttt">
					<label for="goodtttt"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view5" value="good" id="good2tttt">
					<label for="good2tttt"> good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view5" value="poor" id="poor2tttt">
					<label for="poor2tttt">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view5" value="bad" id="bad2tttt">
					<label for="bad2tttt">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>6.Other/Overall Feedback</h2>
			<textarea placeholder="Additional comments" class="w3l_summary" name="view6" required=""></textarea>

			<center><input type="submit" value="submit Feedback" class="agileinfo" name="submit" /></center>
		</form>
	</div>
	<div class="agileits_copyright text-center">
		<p>© 2022 </p>
	</div>
    
    
   
         <?php


    $db = mysqli_connect("localhost","root","","php_db");
    
    
     $query1=mysqli_query($db,'select * from ifsem2faculty where id=1');
   while($row=mysqli_fetch_assoc($query1))
   {
    ?>
     <input type="text" name="vi" value="<?php echo $row['AMT'] ;?>" id="vai">
     <?php
    }
        
   

?>
        

 
</body>

</html>