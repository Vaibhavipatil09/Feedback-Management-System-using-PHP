<?php $db = mysqli_connect("localhost","root","","php_db");
      if(isset($_POST['submit']))
      {
        if(!empty($_POST['radio']))
         {
         
          $class="IF SEM 6";
          if($_POST['radio']=="WMN")
         {
          $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Wireless Mobile Network')";
          $result=mysqli_query($db, $query);
            if($result)
            {
            echo "<script>alert('Details saved successfully');</script>";
            header("Location:sem6sub2.php");
            } 
              exit();
          }
          if($_POST['radio']=="MGT")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Management')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem6sub1.php");
             } 
               exit();
           }
          if($_POST['radio']=="WBP")
          {
           $query="INSERT INTO `iffaculty` ( `class`, `subject`) VALUES ('$class', 'Web based Application using php')";
           $result=mysqli_query($db, $query);
             if($result)
             {
             echo "<script>alert('Details saved successfully');</script>";
             header("Location:sem6sub3.php");
             } 
               exit();
           }
           if($_POST['radio']=="MAD")
           {
            $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Mobile Applicaton Development')";
            $result=mysqli_query($db, $query);
              if($result)
              {
              echo "<script>alert('Details saved successfully');</script>";
              header("Location:sem6sub4.php");
              } 
                exit();
            }
            if($_POST['radio']=="E1")
            {
             $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Emerging trends in CO and IF')";
             $result=mysqli_query($db, $query);
               if($result)
               {
               echo "<script>alert('Details saved successfully');</script>";
               header("Location:sem6sub5.php");
               } 
                 exit();
             }
             if($_POST['radio']=="CPP")
             {
              $query="INSERT INTO `iffaculty` ( `class`, `subject`)  VALUES ('$class', 'Capstone Project Planning and Report writing')";
              $result=mysqli_query($db, $query);
                if($result)
                {
                echo "<script>alert('Details saved successfully');</script>";
                header("Location:sem6sub6.php");
                } 
                  exit();
              }
             
        } 
        
      }

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="FEEDBACK.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>SUBJECTS</title>

</head>


<body>
  <center>
  <div class="container">

    <form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            
            <h2 id="text"><b >Choose the subject to give feedback</b></h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <div id="div1">
            <div class="form-group">


<br>
<h3>IF 6th SEMISTER</h3>
<form  action="" method="post" id="form3">
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="MGT" checked value="MGT">
  <label class="form-check-label" for="MGT">
   
    Management
  </label>
</div>
<br>
<div class="form-check">
  
  <input class="form-check-input" type="radio" name="radio" id="WMN" checked value="WMN">
  <label class="form-check-label" for="WMN">
   
    Wireless Mobile Network
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="WBP" checked  value="WBP">
  <label class="form-check-label" for="WBP">
    Web based Application using php
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="MAD" checked value="MAD">
  <label class="form-check-label" for="MAD">
    Mobile Applicaton Development
    
  </label>
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="E1" checked value="E1">
  <label class="form-check-label" for="E1">
    Emerging trends in CO and IF
    
  </label>
 
</div>
<br>
<div class="form-check">
  <input class="form-check-input" type="radio" name="radio" id="CPP" checked value="CPP">
  <label class="form-check-label" for="CPP">
    Capstone Project Execution <br> & Report Writing
    
  </label>
  <br><br>
</div>


            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                <button type="submit" name="submit"
                  class="btn btn-warning">&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp</button>
              </div>
            </div>

      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>