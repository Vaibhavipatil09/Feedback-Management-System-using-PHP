<!DOCTYPE html>
<html lang="en">

<head>

    <title>PDF</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        #div1 {
            background-color: white;
            border: 1px solid #cccccc;
            padding: 16px;
        }

        body {
            background-color: #e9ebee;
        }
    </style>

</head>

<body>
    <div class="Container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div id="div1">
                   

    <?php
                        $con=new PDO("mysql:host=localhost;dbname=php_db","root","");
                        $query="SELECT*FROM iffaculty";
                        $result =$con->prepare($query);
                        $result->execute();

                        $con1=new PDO("mysql:host=localhost;dbname=php_db","root","");
                        $query1="SELECT*FROM fedfaculty";
                        $result1 =$con1->prepare($query1);
                        $result1->execute();

                        if($result->rowCount() && $result1->rowCount())
                        

                        {
    
        while($sem1 = $result->fetch() && $sem2 = $result1->fetch())
        {
            
                       header("Location:sem11.php");
                       ?>
<?php

                                }
                        }
                        else
                        {
                            echo "<br><br>Data Not Found";
                        }
?>

                    </table>
                </div>

            </div>
            <div class="col-md-3"></div>
        </div>


    </div>

</body>

</html>