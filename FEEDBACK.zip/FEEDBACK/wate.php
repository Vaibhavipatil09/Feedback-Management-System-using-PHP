<?php
   $db = mysqli_connect("localhost","root","","php_db");
   if(isset($_POST['submit']))
   {
   
        $name=$_POST['name'];
        $roll=$_POST['roll'];
        $class=$_POST['class'];
        $contact=$_POST['contact'];
        $email=$_POST['email'];
      

        $query="INSERT INTO `details` ( `name`, `roll`,`class`,`contact`,`email`) VALUES ('$name', '$roll', '$class', '$contact', '$email')";
        
        $result=mysqli_query($db, $query);
        if($result)
        {
        echo "<script>alert('Details saved successfully');</script>";
        if($class=="IF1"){
          header("Location:admin.php");
          exit();
        }
        
        }
        else
        {
        echo "<script>alert('something went wrong');</script>";
        }
   }
?>
?><!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>Document</title>
<style>#success_message{ display: none;}
body{
    background-image:url("register.webp");
    background-repeat:no-repeat;
    background-size: 100%;
    background-position:center;
    background-attachment: fixed;
	
	
	
  }
  #sub{
    background-color:"purple";
  }
  h2{
    
    color: black;
  }
  #div1{
background:white;
width: 700px;
height: 500px;
  }
label
{
  
   color:black;
    position: absolute;
    left: 450px;

}

  input
  {
      
      position: absolute;
      left: 700px;
  }
  select
  {
      
      position: absolute;
      left: 580px;
  }
  #start1{
    position: absolute;
      left: 700px;
  }
  #start2{
    position: absolute;
      left: 700px;
  }
  #start3{
   width: 244px;
  }</style>
</head>


<body>
  <center>
  <div class="container">

   
	<form class="well form-horizontal" action=" " method="post" id="contact_form">
      <fieldset>

        <!-- Form Name -->
        <legend>
          <center>
            <h2><b>Student Details</h2>
          </center>
        </legend><br>
        <center>
          <!-- Text input-->
          <br><br>
          <div id="div1">
            <div class="form-group">


<br><br><br><br>
              <label for="start">Student Full Name</label>

              <input type="text" id="start" name="name"placeholder="Student Full Name">





            </div>
            <br> <br>
            <div class="form-group">

              <label for="start">Roll No</label>

              <input type="text" id="start" placeholder="Roll No" name="roll">


            </div>
            <br> <br>
          

            <!-- Text input-->
            <div class="form-group">

              <label for="start">Class</label>

              <input type="text" id="start" placeholder="Eg.IF1(1=sem 1)"name="class">
            </div>


            <!-- Text input-->
            <br><br>
            <div class="form-group">



              <label for="start">Contact No</label>

              <input type="text" id="start" placeholder="Contact No" name="contact">
            </div>
            <br><br>
            <div class="form-group">



              <label for="start">Email Id</label>

              <input type="text" id="start" placeholder="Email Id" name="email">
            </div>

            <!-- Select Basic -->

            <!-- Success message -->
            <div class="alert alert-success" role="alert" id="success_message">Success <i
                class="glyphicon glyphicon-thumbs-up"></i> Success!.</div><br><br>

            <!-- Button -->
            <div class="form-group">
              <label class="col-md-4 control-label"></label>
              <div class="col-md-4"><br>
                &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<button type="submit"
                  class="btn btn-warning" id="sub">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspSUBMIT <span
                    class="glyphicon glyphicon-send"></span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</button>
              </div>
            </div>
          </div>
      </fieldset>
    </form>
  </div>
  </div><!-- /.container -->
  </center>
  </div>
</center>
</body>

</html>