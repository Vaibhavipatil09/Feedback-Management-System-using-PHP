<!DOCTYPE html>
<html>
<head>
	<title>FeedbacK Engine</title>
	<!-- custom-theme -->

	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } 
	</script>
	<!-- //custom-theme -->
	<link rel="stylesheet" href="style.css">
	<link href="//fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">

</head>

<body class="agileits_w3layouts">
	<h1 class="agile_head text-center">Feedback for collage</h1>
	<div class="w3layouts_main wrap">

		<form action="feedback.php" method="post" class="agile_form">
			<h2>1.How much would you like to rate us for collage
				Cleanliness</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view" value="excellent" id="excellent1" required>
					<label for="excellent1">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view" value="good" id="good2">
					<label for="good2"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view" value="good" id="good3">
					<label for="good3">good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view" value="poor" id="poor4">
					<label for="poor4">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view" value="neutral" id="neutral4">
					<label for="neutral4">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>2.How much would you like to rate us for College
				Maintainance Of Classrooms</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view2" value="excellent" id="excellentt" required>
					<label for="excellentt">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view2" value="verygood" id="goodt">
					<label for="goodt"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view2" value="good" id="good2t">
					<label for="good2t"> good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view2" value="poor" id="poor2t">
					<label for="poor2t">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view2" value="bad" id="bad2t">
					<label for="bad2t">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>3.How much would you like to rate us For
				Computers lab,Physics lab,Chemistry Lab</h2>
				<ul class="agile_info_select">
					<li><input type="radio" name="view3" value="excellent" id="excellenttt" required>
						<label for="excellenttt">excellent</label>
						<div class="check w3"></div>
					</li>
					<li><input type="radio" name="view3" value="verygood" id="goodtt">
						<label for="goodtt"> very good</label>
						<div class="check w3ls"></div>
					</li>
					<li><input type="radio" name="view3" value="good" id="good2tt">
						<label for="good2tt"> good</label>
						<div class="check w3ls"></div>
					</li>
					
					<li><input type="radio" name="view3" value="poor" id="poor2tt">
						<label for="poor2tt">poor</label>
						<div class="check w3_agileits"></div>
					</li>
					<li><input type="radio" name="view3" value="bad" id="bad2tt">
						<label for="bad2tt">bad</label>
						<div class="check wthree"></div>
					</li>
				</ul>
			<h2>4.How much would you like to rate us for
				Collage Security"</h2>
				<ul class="agile_info_select">
					<li><input type="radio" name="view3" value="excellent" id="excellentttt" required>
						<label for="excellentttt">excellent</label>
						<div class="check w3"></div>
					</li>
					<li><input type="radio" name="view3" value="verygood" id="goodttt">
						<label for="goodttt"> very good</label>
						<div class="check w3ls"></div>
					</li>
					<li><input type="radio" name="view3" value="good" id="good2ttt">
						<label for="good2ttt"> good</label>
						<div class="check w3ls"></div>
					</li>
					
					<li><input type="radio" name="view3" value="poor" id="poor2ttt">
						<label for="poor2ttt">poor</label>
						<div class="check w3_agileits"></div>
					</li>
					<li><input type="radio" name="view3" value="bad" id="bad2ttt">
						<label for="bad2ttt">bad</label>
						<div class="check wthree"></div>
					</li>
				</ul>
			<h2>5.How much would you like to rate our Collage
				Library</h2>
			<ul class="agile_info_select">
				<li><input type="radio" name="view3" value="excellent" id="excellenttttt" required>
					<label for="excellenttttt">excellent</label>
					<div class="check w3"></div>
				</li>
				<li><input type="radio" name="view3" value="verygood" id="goodtttt">
					<label for="goodtttt"> very good</label>
					<div class="check w3ls"></div>
				</li>
				<li><input type="radio" name="view3" value="good" id="good2tttt">
					<label for="good2tttt"> good</label>
					<div class="check w3ls"></div>
				</li>
				
				<li><input type="radio" name="view3" value="poor" id="poor2tttt">
					<label for="poor2tttt">poor</label>
					<div class="check w3_agileits"></div>
				</li>
				<li><input type="radio" name="view3" value="bad" id="bad2tttt">
					<label for="bad2tttt">bad</label>
					<div class="check wthree"></div>
				</li>
			</ul>
			<h2>6.Other/Overall Feedback</h2>
			<textarea placeholder="Additional comments" class="w3l_summary" name="comments" required=""></textarea>

			<center><input type="submit" value="submit Feedback" class="agileinfo" /></center>
		</form>
	</div>
	<div class="agileits_copyright text-center">
		<p>© 2022 </p>
	</div>
</body>

</html>